import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Car, MapPin, User, UserCog } from "lucide-react"

export default function Home() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-blue-100 to-blue-200">
      <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-10"></div>
      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <div className="mb-8 inline-block">
            <div className="relative w-24 h-24 mx-auto mb-4">
              <div className="absolute inset-0 bg-blue-600 rounded-full shadow-lg transform -rotate-6"></div>
              <div className="absolute inset-0 bg-blue-500 rounded-full shadow-lg transform rotate-3"></div>
              <div className="relative flex items-center justify-center w-full h-full bg-blue-400 rounded-full shadow-lg">
                <Car className="w-12 h-12 text-white" />
              </div>
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-gray-800 drop-shadow-md">
            Find Parking <span className="text-blue-600">In Real-Time</span>
          </h1>
          <p className="text-xl mb-10 text-gray-700">
            Locate available parking spots, view restricted areas, and book your space with just a few clicks.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-lg mx-auto">
            <Link href="/user/login">
              <Button className="w-full h-16 text-lg bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 shadow-lg hover:shadow-xl transition-all duration-200 rounded-xl border-2 border-green-400 border-b-4 border-r-4 border-b-green-700 border-r-green-700 flex items-center justify-center gap-2">
                <User className="w-6 h-6" />
                User Login
              </Button>
            </Link>
            <Link href="/owner/login">
              <Button className="w-full h-16 text-lg bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all duration-200 rounded-xl border-2 border-blue-400 border-b-4 border-r-4 border-b-blue-700 border-r-blue-700 flex items-center justify-center gap-2">
                <UserCog className="w-6 h-6" />
                Owner Login
              </Button>
            </Link>
          </div>
          <div className="mt-6">
            <Link href="/user/parking">
              <Button
                variant="outline"
                className="h-14 text-lg bg-white hover:bg-gray-100 shadow-md hover:shadow-lg transition-all duration-200 rounded-xl border-2 border-gray-300 border-b-4 border-r-4 border-b-gray-400 border-r-gray-400 flex items-center justify-center gap-2"
              >
                <MapPin className="w-5 h-5" />
                View Parking Map
              </Button>
            </Link>
          </div>
        </div>

        <div className="mt-20 max-w-4xl mx-auto bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-xl border-2 border-gray-200">
          <h2 className="text-2xl font-bold mb-6 text-gray-800">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-blue-50 p-6 rounded-xl shadow-md border-2 border-blue-100 border-b-4 border-r-4 border-b-blue-200 border-r-blue-200">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mb-4 shadow-md">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Find Parking</h3>
              <p className="text-gray-600">Search for available parking spots near your location in real-time.</p>
            </div>
            <div className="bg-green-50 p-6 rounded-xl shadow-md border-2 border-green-100 border-b-4 border-r-4 border-b-green-200 border-r-green-200">
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mb-4 shadow-md">
                <Car className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Book a Spot</h3>
              <p className="text-gray-600">Reserve your parking space with just a few clicks.</p>
            </div>
            <div className="bg-purple-50 p-6 rounded-xl shadow-md border-2 border-purple-100 border-b-4 border-r-4 border-b-purple-200 border-r-purple-200">
              <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mb-4 shadow-md">
                <UserCog className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Manage Parking</h3>
              <p className="text-gray-600">Parking owners can register and manage their parking spaces.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

