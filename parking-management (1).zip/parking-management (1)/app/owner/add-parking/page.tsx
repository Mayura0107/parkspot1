"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon, Car, MapPin } from "lucide-react"
import { cn } from "@/lib/utils"

export default function AddParkingPage() {
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const [formData, setFormData] = useState({
    ownerName: "",
    parkingName: "",
    address: "",
    totalSpaces: "",
    pricePerHour: "",
    latitude: "",
    longitude: "",
  })
  const [date, setDate] = useState<Date | undefined>(new Date())

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // In a real app, this would be a real API call
      // const response = await axios.post("/api/owner/add-parking", formData)

      // Simulating API call for demo purposes
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Show success message
      alert("Parking space registered successfully!")

      // Reset form
      setFormData({
        ownerName: "",
        parkingName: "",
        address: "",
        totalSpaces: "",
        pricePerHour: "",
        latitude: "",
        longitude: "",
      })

      // Redirect to a confirmation page or dashboard
      // router.push("/owner/dashboard")
    } catch (error) {
      alert("Failed to register parking space. Please try again.")
      console.error("Registration error:", error)
    } finally {
      setLoading(false)
    }
  }

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData((prev) => ({
            ...prev,
            latitude: position.coords.latitude.toString(),
            longitude: position.coords.longitude.toString(),
          }))
        },
        (error) => {
          console.error("Error getting location:", error)
          alert("Could not get your current location. Please enter coordinates manually.")
        },
      )
    } else {
      alert("Geolocation is not supported by this browser.")
    }
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gradient-to-b from-blue-100 to-blue-200 p-4">
      <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-10"></div>
      <Card className="w-full max-w-2xl relative z-10 border-2 border-gray-200 shadow-2xl bg-white/90 backdrop-blur-sm rounded-2xl border-b-4 border-r-4 border-b-gray-300 border-r-gray-300">
        <CardHeader className="space-y-1">
          <CardTitle className="text-3xl font-bold text-center">Register Parking Space</CardTitle>
          <CardDescription className="text-center">
            Add your parking space to make it available for users
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="ownerName">Owner Name</Label>
                <Input
                  id="ownerName"
                  name="ownerName"
                  placeholder="Enter owner name"
                  value={formData.ownerName}
                  onChange={handleInputChange}
                  required
                  className="bg-white border-2 border-gray-300 focus:border-blue-500 h-12 shadow-inner rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="parkingName">Parking Name</Label>
                <Input
                  id="parkingName"
                  name="parkingName"
                  placeholder="Enter parking name"
                  value={formData.parkingName}
                  onChange={handleInputChange}
                  required
                  className="bg-white border-2 border-gray-300 focus:border-blue-500 h-12 shadow-inner rounded-xl"
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  name="address"
                  placeholder="Enter full address"
                  value={formData.address}
                  onChange={handleInputChange}
                  required
                  className="bg-white border-2 border-gray-300 focus:border-blue-500 h-12 shadow-inner rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="totalSpaces">Total Parking Spaces</Label>
                <Input
                  id="totalSpaces"
                  name="totalSpaces"
                  type="number"
                  placeholder="Enter total spaces"
                  value={formData.totalSpaces}
                  onChange={handleInputChange}
                  required
                  min="1"
                  className="bg-white border-2 border-gray-300 focus:border-blue-500 h-12 shadow-inner rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pricePerHour">Price Per Hour ($)</Label>
                <Input
                  id="pricePerHour"
                  name="pricePerHour"
                  type="number"
                  placeholder="Enter price per hour"
                  value={formData.pricePerHour}
                  onChange={handleInputChange}
                  required
                  min="0"
                  step="0.01"
                  className="bg-white border-2 border-gray-300 focus:border-blue-500 h-12 shadow-inner rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label>Available From</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal bg-white border-2 border-gray-300 focus:border-blue-500 h-12 shadow-inner rounded-xl",
                        !date && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Location Coordinates</Label>
                <div className="grid grid-cols-2 gap-4">
                  <Input
                    id="latitude"
                    name="latitude"
                    placeholder="Latitude"
                    value={formData.latitude}
                    onChange={handleInputChange}
                    required
                    className="bg-white border-2 border-gray-300 focus:border-blue-500 h-12 shadow-inner rounded-xl"
                  />
                  <Input
                    id="longitude"
                    name="longitude"
                    placeholder="Longitude"
                    value={formData.longitude}
                    onChange={handleInputChange}
                    required
                    className="bg-white border-2 border-gray-300 focus:border-blue-500 h-12 shadow-inner rounded-xl"
                  />
                </div>
                <Button
                  type="button"
                  variant="outline"
                  onClick={getCurrentLocation}
                  className="mt-2 w-full bg-white hover:bg-gray-100 shadow-md hover:shadow-lg transition-all duration-200 rounded-xl border-2 border-gray-300 border-b-4 border-r-4 border-b-gray-400 border-r-gray-400 flex items-center justify-center gap-2"
                >
                  <MapPin className="w-4 h-4" />
                  Use Current Location
                </Button>
              </div>
            </div>
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 mt-6 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all duration-200 rounded-xl border-2 border-blue-400 border-b-4 border-r-4 border-b-blue-700 border-r-blue-700 flex items-center justify-center gap-2"
            >
              <Car className="w-5 h-5" />
              {loading ? "Registering..." : "Register Parking Space"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

