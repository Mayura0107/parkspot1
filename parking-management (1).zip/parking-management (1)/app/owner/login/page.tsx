"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Lock, UserCog } from "lucide-react"

export default function OwnerLoginPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // In a real app, this would be a real API call
      // const response = await axios.post("/api/owner/login", { username, password })

      // Simulating API call for demo purposes
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Simulate successful login
      const owner = { id: 1, username, name: "Parking Owner" }

      // Store owner in localStorage or state management
      localStorage.setItem("owner", JSON.stringify(owner))

      // Redirect to add parking page
      router.push("/owner/add-parking")
    } catch (error) {
      alert("Login failed. Please check your credentials.")
      console.error("Login error:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gradient-to-b from-blue-100 to-blue-200 p-4">
      <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-10"></div>
      <Card className="w-full max-w-md relative z-10 border-2 border-gray-200 shadow-2xl bg-white/90 backdrop-blur-sm rounded-2xl border-b-4 border-r-4 border-b-gray-300 border-r-gray-300">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-3xl font-bold">Owner Login</CardTitle>
          <CardDescription>Enter your credentials to manage your parking spaces</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <UserCog className="h-5 w-5 text-gray-400" />
                </div>
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="pl-10 bg-white border-2 border-gray-300 focus:border-blue-500 h-12 shadow-inner rounded-xl"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <Lock className="h-5 w-5 text-gray-400" />
                </div>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="pl-10 bg-white border-2 border-gray-300 focus:border-blue-500 h-12 shadow-inner rounded-xl"
                />
              </div>
            </div>
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 mt-6 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all duration-200 rounded-xl border-2 border-blue-400 border-b-4 border-r-4 border-b-blue-700 border-r-blue-700"
            >
              {loading ? "Logging in..." : "Login"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col">
          <p className="text-sm text-center text-gray-500 mt-4">
            Don&apos;t have an account? Contact admin to register as a parking owner.
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}

